const ContactController = require("./contact.controller");

module.exports = {
  ContactController,
};
