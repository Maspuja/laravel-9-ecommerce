module.exports = () => ({
  plugins: {
    autoprefixer: {}
  }
})